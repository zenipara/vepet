# Website dan Manajemen Klinik Petshop (IndoPetCare)

## 1. Portal Pelanggan (Customer Experience)
*   **Dashboard Kesehatan & Profil:** Visualisasi metrik kesehatan, multi-pet management, dan feed update terkini.
*   **Sistem Reservasi Digital:** Smart booking workflow, katalog layanan, dan integrasi slot real-time.
*   **Fitur Transparansi "Recovery Journey":** Live status tracking, daily photo updates, dan direct vet notes.

## 2. Operasional Klinik & Staf (Clinic Operations)
*   **Pusat Komando (Dashboard):** Appointment monitor, critical alerts, staff activity log, dan in-patient overview.
*   **Rekam Medis Elektronik (EMR):** Patient directory, comprehensive medical history, treatment input, dan document/photo upload.
*   **Manajemen Stok Barang & Inventaris:** Katalog aset medis, real-time stock tracking, expiry date tracking, automated reorder point, dan vendor management.

## 3. Fitur Publik & Keamanan
*   **Public Landing Page:** Informasi layanan, lokasi, jam operasional, dan testimoni.
*   **Emergency Call System:** Akses cepat 24/7.
*   **Cross-Device Sync & Data Security.**