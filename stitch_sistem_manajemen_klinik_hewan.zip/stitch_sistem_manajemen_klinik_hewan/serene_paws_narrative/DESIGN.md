---
name: Serene Paws Narrative
colors:
  surface: '#f8fafb'
  surface-dim: '#d8dadb'
  surface-bright: '#f8fafb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f5'
  surface-container: '#eceeef'
  surface-container-high: '#e6e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3e4949'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#eff1f2'
  outline: '#6e797a'
  outline-variant: '#bdc9c9'
  surface-tint: '#00696d'
  primary: '#00676b'
  on-primary: '#ffffff'
  primary-container: '#118186'
  on-primary-container: '#f3ffff'
  inverse-primary: '#79d5da'
  secondary: '#904d00'
  on-secondary: '#ffffff'
  secondary-container: '#ffa454'
  on-secondary-container: '#713b00'
  tertiary: '#4f5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#677877'
  on-tertiary-container: '#f3fffe'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#96f1f7'
  primary-fixed-dim: '#79d5da'
  on-primary-fixed: '#002021'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77d'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#d4e6e5'
  tertiary-fixed-dim: '#b8cac9'
  on-tertiary-fixed: '#0e1e1e'
  on-tertiary-fixed-variant: '#3a4a49'
  background: '#f8fafb'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
  status-label:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin: 32px
---

## Brand & Style

The design system is anchored in a philosophy of "Empathetic Efficiency." It targets veterinary professionals who require high-performance tools, but operates within an environment where calm and warmth are essential for pet owners. 

The aesthetic style is **Corporate Modern with a Soft Edge**. It utilizes the reliability of systematic layouts paired with a "Soft UI" approach—relying on subtle depth, high-quality whitespace, and a gentle color palette to reduce cognitive load and emotional stress. The interface should feel clinical but never cold, evoking a sense of trust, cleanliness, and modern care.

## Colors

This design system utilizes a palette designed to balance clinical precision with organic warmth.

- **Primary (Soft Teal):** Used for primary actions, branding, and navigation. It suggests cleanliness and medical professionality without the harshness of traditional navy or royal blue.
- **Secondary (Warm Orange):** Reserved strictly for accents, notifications, and "joy" moments (e.g., vaccination completions, wellness milestones). It provides a high-contrast energetic counterpoint to the teal.
- **Surface & Backgrounds:** We use a hierarchy of clean whites and light greys (`#F8FAFB`) to create "breathing room," ensuring that dense medical data remains legible.
- **Semantic Colors:** Success (Green) and Error (Red) are slightly desaturated to maintain the "Soft" aesthetic while remaining functional for status indicators.

## Typography

The typography system uses **Plus Jakarta Sans** for its unique ability to appear both geometric/modern and friendly/rounded. 

- **Headlines:** Use tighter letter spacing and heavier weights to establish a clear information hierarchy.
- **Body Copy:** Set with generous line heights to ensure long-form medical notes and pet histories are easy to scan.
- **Labels:** Small caps or bold weights are used for data labels (e.g., "Weight," "Species") to distinguish them from the actual data values.

## Layout & Spacing

The design system employs a **12-column fluid grid** with fixed-width constraints for readability on ultra-wide screens. 

- **Grid:** 24px gutters provide significant separation between data-heavy widgets.
- **Rhythm:** An 8px base unit drives all spacing. Elements should follow the `n * 8` rule to maintain a mathematical harmony across the dashboard.
- **Containerization:** Information is grouped into distinct cards to avoid the "spreadsheet feel." Each card uses `md` (24px) padding for an airy, professional look.

## Elevation & Depth

Visual hierarchy is managed through **Tonal Layering** and **Ambient Shadows**. 

1. **Level 0 (Background):** The base canvas uses the neutral light grey.
2. **Level 1 (Cards/Containers):** Pure white backgrounds with a very soft, diffused shadow (15% opacity primary color tint, 20px blur, 4px offset).
3. **Level 2 (Modals/Popovers):** Higher elevation with a 30px blur shadow and a subtle 1px border using the tertiary teal color to define edges.

Avoid harsh black shadows; instead, use shadows tinted with the primary teal to keep the interface looking "clean" and medical.

## Shapes

The shape language is consistently **Rounded**. 

- **Standard Elements:** Buttons, input fields, and small cards use a 0.5rem (8px) radius.
- **Large Containers:** Main dashboard widgets and health charts use a 1rem (16px) radius to soften the layout.
- **Interactive Pill:** Small status indicators (e.g., "Active," "Scheduled") should use full pill-shaping (rounded-full) to distinguish them from buttons.

## Components

- **Buttons:** 
  - *Primary:* Solid Teal with white text. 
  - *Secondary:* Ghost style with Teal border and text. 
  - *Action:* Warm Orange reserved for critical "Emergency" or "Book Appointment" triggers.
- **Health Charts:** 
  - Use smooth Spline curves instead of jagged lines for pet vitals. 
  - Background grids should be extremely faint light grey. 
  - Primary data points use Teal, while "Alert" zones use a Soft Orange wash.
- **Status Indicators:** 
  - Small, pill-shaped chips with a low-opacity background of the status color (e.g., "Stable" is light green background with dark green text).
- **Form Elements:** 
  - Inputs feature a light grey background and no border until focused. Upon focus, they transition to a 2px Teal border with a soft teal outer glow.
  - Labels are always positioned above the field in `label-caps` typography.
- **Cards:** 
  - Pet Profile cards should include a circular image mask for pet photos to maintain the soft shape language.
- **Data Tables:** 
  - Use "Zebra striping" with the neutral background color for readability, removing vertical borders entirely to maintain a modern, open feel.